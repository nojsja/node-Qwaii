/**
 * Created by yangw on 2016/8/13.
 */
module.exports = {
    cookieSecret:'Q',
    db:'Qwaii',
    host:'localhost',
    port:27017,
    user:"Johnson",
    password:"yangwei020154"
};