/**
 * Created by yangw on 2016/8/26.
 */
//限定作用域
$(function () {

});